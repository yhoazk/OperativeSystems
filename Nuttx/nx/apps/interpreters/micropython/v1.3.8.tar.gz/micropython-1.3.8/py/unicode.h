mp_uint_t utf8_ptr_to_index(const byte *s, const byte *ptr);
